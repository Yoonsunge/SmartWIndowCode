﻿using Smartwindow;
using System;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Timers;
using System.Reflection;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Speech.Synthesis;

// GOiy1zaCzjKztL1os6DswC8izo43h9iFScpuPwdG

namespace SmartWindowApp
{
    public partial class Form1 : Form
    {
        int a = 1;
        string tempCmd;
        string humiCmd;

        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "0cKmlAMVMRc3RMBXqBO7JzB1FceB2OsjaRqGdsTM",
            BasePath = "https://smartwindow1-fc553-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        System.Timers.Timer timer;

        System.Timers.Timer timerAutoAction; // timerAutoAction 선언

        // TTS 객체
        SpeechSynthesizer synth = new SpeechSynthesizer();

        // Flag to track TTS state
        bool isTtsAllowed = true;

        public Form1()
        {
            InitializeComponent();
            timerAutoAction = new System.Timers.Timer(); // timerAutoAction 초기화

            // Initialize TTS
            synth.SetOutputToDefaultAudioDevice();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);

            if (client != null)
            {
                MessageBox.Show("Database Connected");
            }

            await RetrieveDataFromFirebase();

            timer = new System.Timers.Timer();
            timer.Interval = 1000; // 1초
            timer.Elapsed += async (obj, args) => await RetrieveDataFromFirebase(); // 타이머가 지정된 간격마다 데이터를 가져옴
            timer.Start();

            if (tempCmd == "1")
            {
                synth.Speak("현재는 온도는 " + txtTemp.Text + "도입니다.");
            }

            if (humiCmd == "1")
            {
                synth.Speak("현재는 습도는 " + txtHumi.Text + "퍼센트입니다.");
            }

            if (a % 2 == 0)
            {
                btnAuto.Text = "자동 조작 OFF";
                lblAuto.Text = "자동 조작 가동중";
                synth.Speak("자동 조작 상태입니다.");
                StartTtsResetTimer();
            }
            else
            {
                btnAuto.Text = "자동 조작 ON";
                lblAuto.Text = "";
                synth.Speak("자동 조작이 중지되었습니다.");
                StartTtsResetTimer();
            }
        }

        private async Task RetrieveDataFromFirebase()
        {
            try
            {
                FirebaseResponse resp = await client.GetAsync("");
                var data = resp.ResultAs<Dictionary<string, string>>();

                if (data.ContainsKey("co2"))
                {
                    double co2Value;
                    if (double.TryParse(data["co2"], out co2Value))
                    {
                        int co2IntValue = Convert.ToInt32(co2Value);
                        txtCo2.Text = co2IntValue.ToString();
                    }
                    else
                    {
                        // CO2 값이 유효한 double 형식이 아닌 경우에 대한 처리
                        txtCo2.Text = "ERROR";
                    }
                }

                if (data.ContainsKey("humi"))
                {
                    txtHumi.Text = data["humi"];
                }

                if (data.ContainsKey("humi_cmd"))
                {
                    humiCmd = data["humi_cmd"];
                }


                if (data.ContainsKey("temp_cmd"))
                {
                    tempCmd = data["temp_cmd"];
                }

                if (data.ContainsKey("temp"))
                {
                    txtTemp.Text = data["temp"];
                }

                if (data.ContainsKey("rain"))
                {
                    double rainValue;
                    if (double.TryParse(data["rain"], out rainValue))
                    {
                        if (rainValue >= 500 && rainValue <= 800)
                        {
                            txtRain.Text = "비가 약간 내림";
                            if (isTtsAllowed)
                            {
                                synth.Speak("비가 약간 내리므로 창문을 닫습니다.");
                                StartTtsResetTimer();
                            }
                        }
                        else if (rainValue > 800)
                            txtRain.Text = "비가 내리지 않음";
                        else if (rainValue < 500)
                        {
                            txtRain.Text = "비가 강하게 내림";
                            if (isTtsAllowed)
                            {
                                synth.Speak("비가 강하게 내리므로 창문을 닫습니다.");
                                StartTtsResetTimer();
                            }
                        }

                    }
                    else
                    {
                        // rain 값이 유효한 double 형식이 아닌 경우에 대한 처리
                        txtRain.Text = "유효하지 않은 값입니다.";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data from Firebase: " + ex.Message);
            }
        }

        private void StartTtsResetTimer()
        {
            isTtsAllowed = false;
            timerAutoAction.Interval = 300000; // 5 minutes
            timerAutoAction.Elapsed += TtsResetTimer_Tick;
            timerAutoAction.Start();
        }

        private void TtsResetTimer_Tick(object sender, ElapsedEventArgs e)
        {
            isTtsAllowed = true;
            timerAutoAction.Stop();
        }

        // Form1이 닫힐 때 타이머 정리
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (timer != null)
            {
                timer.Stop();
                timer.Dispose();
            }
            if (timerAutoAction != null)
            {
                timerAutoAction.Stop();
                timerAutoAction.Dispose();
            }
        }
    

    // Counter 클래스는 Firebase에서 가져온 데이터를 매핑하는 데 사용됩니다.
    public class Counter
    {
        public int cnt { get; set; }
    }

    private void button1_Click(object sender, EventArgs e)
        {
            // Form2 인스턴스 생성
            Form2 form2 = new Form2();

            // Form1 닫기
            this.Hide();

            // Form2 열기
            form2.Show();
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            a++;
            // 버튼의 텍스트를 ON/OFF로 변환하는 함수를 실행한다.
            changeToTextBtn();

            if (a % 2 == 0)
            {
                await client.SetAsync("MODE", 2);
            }
            else
            {
                await client.SetAsync("MODE", 3);
            }
        }

        private void changeToTextBtn()
        {
            if (a % 2 == 0)
            {
                btnAuto.Text = "자동 조작 OFF";
                lblAuto.Text = "자동 조작 가동중";
                synth.Speak("자동 조작 상태입니다.");
                StartTtsResetTimer();
            }
            else
            {
                btnAuto.Text = "자동 조작 ON";
                lblAuto.Text = "";
                synth.Speak("자동 조작이 중지되었습니다.");
                StartTtsResetTimer();
            }
        }
    }
}