﻿using SmartWindowApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace Smartwindow
{
    public partial class Form2 : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "GOiy1zaCzjKztL1os6DswC8izo43h9iFScpuPwdG",
            BasePath = "https://smartwindow-test-default-rtdb.asia-southeast1.firebasedatabase.app/"
        };

        IFirebaseClient client;

        public Form2()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Form2 닫기
            this.Close();

            // Form1 열기
            Form1 form1 = new Form1();
            form1.Show();
        }

        private async void btnOpen_Click(object sender, EventArgs e)
        {
            await UpdateManualValue(1); // manual 변수에 1을 업데이트하여 모터를 열도록 함
        }

        private async void btnClose_Click(object sender, EventArgs e)
        {
            await UpdateManualValue(0); // manual 변수에 0을 업데이트하여 모터를 닫도록 함
        }

        private async Task UpdateManualValue(int value)
        {
            try
            {
                // Firebase에 manual 값을 업데이트합니다.
                var updateData = new Dictionary<string, string>
        {
            { "manual", value.ToString() }
        };
                FirebaseResponse response = await client.UpdateAsync("", updateData);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    // 성공적으로 업데이트된 경우
                    Console.WriteLine("Manual value updated successfully.");
                }
                else
                {
                    // 업데이트에 실패한 경우
                    Console.WriteLine("Failed to update manual value.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating manual value: " + ex.Message);
            }
        }
    }
}