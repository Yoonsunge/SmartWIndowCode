- Firesharp NuGet 패키지 설치 필수

co2
humi
manual : 수동
motor
rain
temp

변수명 참고해서 아두이노 연동해야 함.

TTS 오류 발생 시 :

System.Speech.Synthesis 네임스페이스가 빨간 줄이 생기는 것은 대개 해당 네임스페이스가 프로젝트의 참조에 추가되지 않았거나 사용 중인 .NET Framework 버전에 따라 다를 수 있습니다.

이 네임스페이스를 사용하기 위해서는 프로젝트에 System.Speech 어셈블리를 추가해야 합니다. 이 어셈블리는 .NET Framework에 포함되어 있으며, 프로젝트에 추가하여야 합니다.

프로젝트에 System.Speech 어셈블리를 추가하는 방법은 다음과 같습니다.

프로젝트를 우클릭하고 "솔루션 탐색기"에서 "참조 추가"를 선택합니다.
나타나는 참조 관리자 창에서 "Framework" 탭을 선택합니다.
목록에서 "System.Speech"를 찾아 선택하고 "확인"을 클릭합니다.
이제 System.Speech.Synthesis 네임스페이스를 사용하여 TTS 기능을 사용할 수 있어야 합니다. 만약에 이 방법으로도 문제가 해결되지 않는다면, 프로젝트의 .NET Framework 버전을 확인하고 해당 버전이 TTS 기능을 지원하는지 확인해야 할 수도 있습니다.
