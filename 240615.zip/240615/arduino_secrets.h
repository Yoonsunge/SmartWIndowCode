#define SECRET_SSID "AndroidHotspot5048"
#define SECRET_PASS "q1w2e3r4"
