﻿using Smartwindow;
using System;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Timers;
using System.Reflection;
using System.Threading.Tasks;
using System.Collections.Generic;

// GOiy1zaCzjKztL1os6DswC8izo43h9iFScpuPwdG

namespace SmartWindowApp
{
    public partial class Form1 : Form
    {
        int a = 1;

        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "GOiy1zaCzjKztL1os6DswC8izo43h9iFScpuPwdG",
            BasePath = "https://smartwindow-test-default-rtdb.asia-southeast1.firebasedatabase.app/"
        };

        IFirebaseClient client;

        System.Timers.Timer timer;

        System.Timers.Timer timerAutoAction; // timerAutoAction 선언

        public Form1()
        {
            InitializeComponent();
            timerAutoAction = new System.Timers.Timer(); // timerAutoAction 초기화
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);

            if (client != null)
            {
                MessageBox.Show("Database Connected");
            }

            await RetrieveDataFromFirebase();

            timer = new System.Timers.Timer();
            timer.Interval = 1000; // 1초
            timer.Elapsed += async (obj, args) => await RetrieveDataFromFirebase(); // 타이머가 지정된 간격마다 데이터를 가져옴
            timer.Start();

        }

        private async Task RetrieveDataFromFirebase()
        {
            try
            {
                FirebaseResponse resp = await client.GetAsync("");
                var data = resp.ResultAs<Dictionary<string, string>>();

                if (data.ContainsKey("co2"))
                    txtCo2.Text = data["co2"];

                if (data.ContainsKey("humi"))
                    txtHumi.Text = data["humi"];

                if (data.ContainsKey("temp"))
                    txtTemp.Text = data["temp"];

                if (data.ContainsKey("rain"))
                    txtRain.Text = data["rain"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data from Firebase: " + ex.Message);
            }
        }

        // Form1이 닫힐 때 타이머 정리
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (timer != null)
            {
                timer.Stop();
                timer.Dispose();
            }
        }
    

    // Counter 클래스는 Firebase에서 가져온 데이터를 매핑하는 데 사용됩니다.
    public class Counter
    {
        public int cnt { get; set; }
    }

    private void button1_Click(object sender, EventArgs e)
        {
            // Form2 인스턴스 생성
            Form2 form2 = new Form2();

            // Form1 닫기
            this.Hide();

            // Form2 열기
            form2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a += 1;
            // 버튼의 텍스트를 ON/OFF로 변환하는 함수를 실행한다.
            changeToTextBtn();
        }

        private void changeToTextBtn()
        {
            if (a % 2 == 0)
            {
                btnAuto.Text = "자동 조작 OFF";
                lblAuto.Text = "자동 조작 가동중";
                autoAction(true);
            }
            else
            {
                btnAuto.Text = "자동 조작 ON";
                lblAuto.Text = "";
                autoAction(false);
            }
        }

        private void autoAction(bool startAuto)
        {
            if (startAuto)
            {
                // 자동 조작 시작
                timerAutoAction = new System.Timers.Timer();
                timerAutoAction.Interval = 1000; // 1초마다 실행
                timerAutoAction.Elapsed += TimerAutoAction_Elapsed;
                timerAutoAction.Start();
            }
            else
            {
                // 자동 조작 중지
                if (timerAutoAction != null)
                {
                    timerAutoAction.Stop();
                    timerAutoAction.Dispose();
                }
            }
        }

        private async void TimerAutoAction_Elapsed(object sender, ElapsedEventArgs e)
        {
            // 자동 조작 코드
            int temp = int.Parse(txtTemp.Text);
            int rain = int.Parse(txtRain.Text);
            int co2 = int.Parse(txtCo2.Text);
            int humi = int.Parse(txtHumi.Text);

            // 각 상황에 따른 모터 제어 코드 작성
            if (temp == 24)
            {
                // 창문이 열리게 모터 작동
                await UpdateMotorValue(1);
            }
            else if (temp == 18)
            {
                // 창문이 닫히게 모터 작동
                await UpdateMotorValue(0);
            }
            if (rain == 400)
            {
                // 창문이 열리게 모터 작동
                await UpdateMotorValue(1);
            }
            else if (rain == 500)
            {
                // 창문이 닫히게 모터 작동
                await UpdateMotorValue(0);
            }
            if (co2 == 1000)
            {
                // 창문이 열리게 모터 작동
                await UpdateMotorValue(1);
            }
            else if (co2 == 950)
            {
                // 창문이 닫히게 모터 작동
                await UpdateMotorValue(0);
            }
            if (humi == 60)
            {
                // 창문이 열리게 모터 작동
                await UpdateMotorValue(1);
            }
            else if (humi == 40)
            {
                // 창문이 닫히게 모터 작동
                await UpdateMotorValue(0);
            }
        }

        private async Task UpdateMotorValue(int value)
        {
            try
            {
                // Firebase에 motor 값을 업데이트합니다.
                var updateData = new Dictionary<string, string>
        {
            { "motor", value.ToString() }
        };
                FirebaseResponse response = await client.UpdateAsync("", updateData);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    // 성공적으로 업데이트된 경우
                    Console.WriteLine("Motor value updated successfully.");
                }
                else
                {
                    // 업데이트에 실패한 경우
                    Console.WriteLine("Failed to update motor value.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating motor value: " + ex.Message);
            }
        }
    }
}

