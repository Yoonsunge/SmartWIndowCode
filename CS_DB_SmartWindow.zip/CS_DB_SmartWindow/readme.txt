Firesharp NuGet 패키지 설치 필수

co2
humi
manual : 수동
motor
rain
temp

변수명 참고해서 아두이노 연동해야 함.