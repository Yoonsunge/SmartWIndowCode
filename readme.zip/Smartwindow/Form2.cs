﻿using SmartWindowApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Speech.Synthesis;

namespace Smartwindow
{
    public partial class Form2 : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "0cKmlAMVMRc3RMBXqBO7JzB1FceB2OsjaRqGdsTM",
            BasePath = "https://smartwindow1-fc553-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        // TTS 객체
        SpeechSynthesizer synth = new SpeechSynthesizer();


        public Form2()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);

            // Initialize TTS
            synth.SetOutputToDefaultAudioDevice();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Form2 닫기
            this.Close();

            // Form1 열기
            Form1 form1 = new Form1();
            form1.Show();
        }

        private async void btnOpen_Click(object sender, EventArgs e)
        {
            await client.SetAsync("MODE", 1);
            synth.Speak("창문이 열립니다");
            await Task.Delay(5000); // 5초 동안 대기
            await client.SetAsync("MODE", 3); // 모터 동작이 멈추도록 하기 위한 MODE 값 설정
        }

        private async void btnClose_Click(object sender, EventArgs e)
        {
            await client.SetAsync("MODE", 0);
            synth.Speak("창문이 닫힙니다");
            await Task.Delay(5000); // 5초 동안 대기
            await client.SetAsync("MODE", 3); // 모터 동작이 멈추도록 하기 위한 MODE 값 설정
        }

        private async void Form2_Load(object sender, EventArgs e)
        {
            synth.Speak("수동 조작 화면입니다");
            await client.SetAsync("MODE", 3); // 모터 동작이 멈추도록 하기 위한 MODE 값 설정
        }
    }
}